import React from 'react';
import Button from './Button';

const App = () => {
  return (
    <div>
      <Button margin="20px" width={300}>
        Clique Aqui
      </Button>
    </div>
  );
};

export default App;
