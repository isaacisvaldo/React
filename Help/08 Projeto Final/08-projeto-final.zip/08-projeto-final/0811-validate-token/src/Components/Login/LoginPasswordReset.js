import React from 'react';

const LoginPasswordReset = () => {
  return <div></div>;
};

export default LoginPasswordReset;
