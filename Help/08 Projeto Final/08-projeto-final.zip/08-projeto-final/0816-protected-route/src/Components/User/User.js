import React from 'react';

const User = () => {
  return <div>Usuário</div>;
};

export default User;
