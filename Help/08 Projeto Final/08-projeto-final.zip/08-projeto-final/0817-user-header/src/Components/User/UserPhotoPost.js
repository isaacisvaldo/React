import React from 'react';

const UserPhotoPost = () => {
  return <div>Postar foto</div>;
};

export default UserPhotoPost;
