import React from 'react';

const UserStats = () => {
  return <div>Estatísticas</div>;
};

export default UserStats;
