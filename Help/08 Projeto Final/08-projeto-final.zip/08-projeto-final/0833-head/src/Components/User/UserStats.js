import React from 'react';
import Head from '../Helper/Head';

const UserStats = () => {
  return (
    <div>
      <Head title="Estatísticas" />
      Estatísticas
    </div>
  );
};

export default UserStats;
